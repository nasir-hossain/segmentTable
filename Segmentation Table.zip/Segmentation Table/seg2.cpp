#include <iostream>
#include <fstream>
// this is for file handling

using namespace std;

int test[8][2];
int output[128];

int main()
{

    int a,bound;
    int flag=0,bin,offset,seg=0,d=1,mem=0;

    ifstream fp("test.txt");
    ifstream fp2("output.txt");

    // this is for reading and opening existing file test.txt & output.txt




    int row=0,column=0;
    for(int j=0; j<8; j++)
    {
        for(int row = 0; row <8; row++)
    {
        for(int column = 0; column < 2; column++)
        {
            fp >> test[row][column];
            // from fp we read the characters
        }
    }
    fp.close();

        for(int out=0; out<=127; out++)
        {
            fp2>>output[out];
        }
        fp2.close();
        cout<<"Case NO :"<<j+1<<endl;
        cout<<"Enter the Virtual Address : ";
        cin>>a;
        int temp=a;
        bound=0;
        int base=0;
        seg=0;
        mem=0;
        flag=0;
        offset=0;
        column=0;
        d=1;


        int arr[9]= {0,0,0,0,0,0,0,0,0};


        while(a>0)
        {
            bin = a % 2;
            arr[flag]=bin;
            a /= 2;
            flag++;
            //binary conversion
        }
        //cout<<flag<<endl;


        if(flag<=9)
        {

            for(int f=8; f>=0; f--)
            {
                cout<<arr[f];
            }
            cout<<endl;

            for(int c=7; c<=8; c++)
            {
                //cout<<arr[c]<<" \n";

                if(arr[c]==0)
                {
                    seg=seg+0;
                }
                if(arr[c]==1)
                {
                    seg=seg+d;
                }
                d=d*2;

            } //separating segment bit

            d=1;
            for(int c=0; c<=6; c++)
            {

                if(arr[c]==0)
                {
                    offset=offset+0;
                }

                if(arr[c]==1)
                {
                    offset=offset+d;
                }

                d=d*2;

            } //calculate offset


            base=base+test[row][column];
            cout<<"Base "<< base<<endl;
            mem=base+offset;
            cout<<"Mem "<< mem<<endl;
            column++;
            bound=base+test[row][column];
            cout<<"Bound "<< bound<<endl;
            row++;
            if(mem>=base && mem<=bound)
            {
                if(mem<=128)
                {
                    if(seg==0)
                    {
                        cout<<"The address is in Segment "<<seg<<" < Code Segment >\n";
                    }
                    else if(seg==1)
                    {
                        cout<<"The address is in Segment "<<seg<<" < Data Segment >\n";
                    }
                    else if(seg==2)
                    {
                        cout<<"The address is in Segment "<<seg<<" < Heap Segment >\n";
                    }
                    else if(seg==3)
                    {
                        cout<<"The address is in Segment "<<seg<<" < Stack Segment >\n";
                    }


                    cout<<"Physical Memroy  position is "<<mem;
                    cout<<endl<<"Physical Address of "<<temp<<" is ="<<output[mem]<<endl<<endl<<endl;
                }
                else
                {
                    cout<<"Physical memory position is indicating bigger than total memory"<<endl<<endl<<endl;
                }
            }

            else
            {
                cout<<"Out of Bound"<<endl<<endl<<endl;
            }
        }
        else
        {
            base=base+test[row][column];
            mem=base+offset;
            column++;
            bound=base+test[row][column];
            row++;
            cout<<"Offset bit is more than 7 bit"<<endl<<endl<<endl;
        }
    }


    return 0;
}



